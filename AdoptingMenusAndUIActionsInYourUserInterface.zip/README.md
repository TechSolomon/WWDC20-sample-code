# Adopting Menus and UIActions in your User Interface

Add menus to your user interface, with built-in button support and bar-button items, and create custom menu experiences.

## Overview

- Note: This sample code project is associated with WWDC20 session [10052: Build with iOS Pickers, Menus and Actions](https://developer.apple.com/wwdc20/10052/).