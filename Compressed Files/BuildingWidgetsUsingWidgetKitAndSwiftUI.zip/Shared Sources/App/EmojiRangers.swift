/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The app object.
*/
import SwiftUI

@main
struct EmojiRangers: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
