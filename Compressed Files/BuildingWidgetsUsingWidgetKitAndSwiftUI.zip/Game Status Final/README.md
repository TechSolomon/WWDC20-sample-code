# Emoji Rangers: Finished Project

## Overview

Explore the completed project for the three-part Widgets Code-along WWDC20 video series.

[10034: Widgets Code-along, part 1: The adventure begins](https://developer.apple.com/wwdc20/10034/)
[10035: Widgets Code-along, part 2: Alternate timelines](https://developer.apple.com/wwdc20/10035/)
[10036: Widgets Code-along, part 3: Advancing timelines](https://developer.apple.com/wwdc20/10036/)
